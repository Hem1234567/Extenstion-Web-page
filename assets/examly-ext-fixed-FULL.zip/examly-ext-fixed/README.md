# Examly AI Automation Extension — v4.0.0

Fully automated Examly / iamneo course completion. **Zero human interaction required.**

---

## ✅ What's Fixed in v4.0.0

| Problem | Fix |
|---|---|
| Delay between folder expansion and module processing | Removed 2-second sleep — runs instantly now |
| Stops at MCQ even when MCQ mode is OFF | Skips MCQ questions silently when MCQ not selected |
| Doesn't auto-click "Take Test / Resume / Retake" | Auto-clicks all entry buttons immediately |
| Doesn't auto-click YES to end test | Retries clicking YES/OK/CONFIRM up to 10 times |
| Video play button not clicked | Aggressively clicks 15+ play button selectors |
| MCQ selects only last option / skips questions | AI reads question + all options, picks correct one |
| MCQ skips some questions | Navigates to every unattempted question |
| Full Automation button didn't auto-start | Now selects all modes AND starts immediately |

---

## 🚀 Installation

1. Open Chrome → `chrome://extensions`
2. Enable **Developer Mode** (top right)
3. Click **Load unpacked** → select the `examly-ext-fixed` folder
4. Pin the extension icon

---

## 🔑 Setup

1. Click the extension icon
2. Paste your **Gemini API key** (free at [aistudio.google.com](https://aistudio.google.com/app/apikey)) → Save
3. Or switch to **OpenRouter** and paste that key

---

## ▶️ How to Use

### Option A — Full Automation (Recommended)
1. Open your Examly course level page
2. Click the extension icon
3. Click **⚡ Full Automation — Start Everything Now**
4. Sit back — the bot opens all folders, watches all videos, answers all MCQs with AI, solves all coding tests, and ends the test automatically

### Option B — Selective
1. Toggle which modes to enable: **Video**, **MCQ**, **Coding**
2. Click **▶ Start Selected Automation**

---

## 🤖 What It Does Automatically

### 📁 Folders
- Expands all collapsed course folders instantly (no delay)
- Processes modules top-to-bottom

### ▶️ Videos
- Auto-clicks the Play button
- Sets playback speed to 2×
- Seeks near end to finish faster
- Moves to next module when done

### 📝 MCQ Tests
- Auto-clicks "Take Test" / "Agree & Proceed" / "Enable Fullscreen"
- Sends question + all options to AI
- AI selects the **correct answer** (not first/last — actual correct)
- Navigates to every unattempted question
- Submits test, types END, clicks YES automatically

### 💻 Coding Tests
- Auto-clicks "Take Test" / "Resume"
- Reads the full problem statement + test cases
- Asks AI to generate correct code in the detected language
- Pastes code, compiles, and retries up to 5× if it fails
- Submits coding answer automatically
- Clicks YES to end test

---

## 🛠 Supported AI Providers

| Provider | Models | Cost |
|---|---|---|
| **Gemini** (default) | gemini-2.0-flash, gemini-1.5-pro, etc. | Free tier available |
| **OpenRouter** | GPT-4o, Claude, Llama 3, etc. | Pay-per-use / free models |

---

## ⚙️ Files

```
examly-ext-fixed/
├── manifest.json     — Extension config (v4.0.0)
├── content.js        — Main automation logic (runs on page)
├── content.css       — Toast notification styles
├── popup.html        — Extension popup UI
├── popup.js          — Popup logic + mode selection
├── background.js     — Service worker (AI code generation)
└── icons/            — Extension icons
```

---

## 🔧 Troubleshooting

- **"Cannot inject on this page"** → Navigate to the Examly course page first, then click the extension
- **MCQ wrong answer** → Try a smarter AI model (e.g. `gemini-1.5-pro` or `openai/gpt-4o`)
- **Coding fails after 5 retries** → The code was submitted with best effort; manually check
- **Video not playing** → The video might require interaction first; click anywhere on the page then restart
- **Test not ending** → Check browser console for `[ExamlyAI]` logs to diagnose
