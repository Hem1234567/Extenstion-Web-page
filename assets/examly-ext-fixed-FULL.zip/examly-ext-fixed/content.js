// =================================================================
//  content.js – Examly AI Automation Extension v5.0.0
//  FIXES: module pre-detection (MCQ/PA/FA/Coding/Video keywords),
//         aggressive auto-click (Take Test / Resume / Retake),
//         auto YES/OK after submit, skip MCQ when only coding selected,
//         process ALL coding modules in the level
// =================================================================

'use strict';

if (window.__examlyLoaded) {
  // already injected — do nothing
} else {
  window.__examlyLoaded = true;

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const log   = (...a) => console.log('%c[ExamlyAI]', 'color:#00e878;font-weight:bold', ...a);
  const warn  = (...a) => console.warn('%c[ExamlyAI]', 'color:#ff7043;font-weight:bold', ...a);
  const isTop = (window === window.top);

  let videoFound    = false;
  let videoFinished = false;

  // =================================================================
  //  AGGRESSIVE CLICK — works on Angular/React apps that ignore
  //  synthetic events by dispatching the full mouse event chain
  // =================================================================
  async function aggressiveClick(el) {
    if (!el) return;
    try {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      await sleep(150);
      el.focus();
      const opts = { bubbles: true, cancelable: true };
      el.dispatchEvent(new MouseEvent('mouseover',  opts));
      el.dispatchEvent(new MouseEvent('mouseenter', opts));
      el.dispatchEvent(new MouseEvent('mousedown',  opts));
      el.dispatchEvent(new MouseEvent('mouseup',    opts));
      el.dispatchEvent(new MouseEvent('click',      opts));
      if (typeof el.click === 'function') el.click();
      // Also try keyboard Enter — some Angular buttons respond to this
      el.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true }));
      el.dispatchEvent(new KeyboardEvent('keyup',   { key: 'Enter', keyCode: 13, bubbles: true }));
    } catch (e) {}
  }

  // Legacy alias
  function safeClick(el) {
    if (!el) return;
    try {
      el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
      el.dispatchEvent(new MouseEvent('click',     { bubbles: true }));
      if (typeof el.click === 'function') el.click();
    } catch (e) {}
  }

  // =================================================================
  //  VIDEO CROSS-FRAME MESSAGING
  // =================================================================
  window.addEventListener('message', evt => {
    if (!evt.data?.action) return;

    if (evt.data.action === 'examly_play_video') {
      const vid = document.querySelector('video');
      if (!vid) return;

      if (!vid._examlyTracked) {
        vid._examlyTracked = true;
        const done = () => {
          if (vid._examlyDone) return;
          vid._examlyDone = true;
          try { window.top.postMessage({ action: 'examly_video_done' }, '*'); } catch (e) {}
        };
        vid.addEventListener('ended', done);
        vid.addEventListener('timeupdate', () => {
          if (vid.duration && vid.currentTime >= vid.duration - 0.5) done();
          const prev = parseFloat(vid._prevTime || 0);
          const stall = parseInt(vid._stall || 0);
          if (Math.abs(vid.currentTime - prev) < 0.1) {
            const s = stall + 1; vid._stall = s;
            if (s >= 5) {
              vid._stall = 0;
              if (vid.duration && vid.currentTime + 30 < vid.duration - 1) vid.currentTime += 30;
              else if (vid.duration) vid.currentTime = vid.duration - 1;
            }
          } else { vid._stall = 0; }
          vid._prevTime = vid.currentTime;
        });
      }

      try { vid.muted = true; vid.playbackRate = 2; vid.defaultPlaybackRate = 2; } catch (e) {}
      if (!vid._examlyDone && vid.duration && isFinite(vid.duration) && vid.duration > 2) {
        if (vid.currentTime < vid.duration - 2) {
          try { vid.currentTime = vid.duration - 1; } catch (e) {}
        }
      }
      if (vid.paused && !vid._examlyDone) vid.play().catch(() => {});
      try { window.top.postMessage({ action: 'examly_video_found' }, '*'); } catch (e) {}
    }

    if (isTop) {
      if (evt.data.action === 'examly_video_found') videoFound = true;
      if (evt.data.action === 'examly_video_done')  videoFinished = true;
    }
  });

  // =================================================================
  //  PING VIDEO — tries every known play button selector
  // =================================================================
  function pingVideo() {
    document.querySelectorAll('video').forEach(v => {
      try { v.muted = true; v.playbackRate = 2; } catch (e) {}
      if (v.paused) v.play().catch(() => {});
      if (!v._examlyTracked) {
        v._examlyTracked = true;
        v.addEventListener('ended', () => { videoFinished = true; });
        v.addEventListener('timeupdate', () => {
          if (v.duration && v.currentTime >= v.duration - 0.5) videoFinished = true;
        });
        videoFound = true;
      }
    });

    const playSelectors = [
      'button[aria-label="Play"]', 'button[title="Play"]',
      '.vjs-big-play-button', '.vjs-play-control',
      '[data-testid="play-button"]', '.play-button',
      '#play0', 'button.play', '.video-play-btn',
      '[class*="play"][class*="btn"]', '[class*="btn"][class*="play"]',
      'img[src*="play"]', 'div[class*="play-icon"]', 'span[class*="play-icon"]',
      '[aria-label*="play" i]', '.ytp-play-button',
    ];
    for (const sel of playSelectors) {
      const btn = document.querySelector(sel);
      if (btn && btn.offsetParent) { safeClick(btn); break; }
    }

    window.postMessage({ action: 'examly_play_video' }, '*');
    document.querySelectorAll('iframe').forEach(f => {
      try { f.contentWindow.postMessage({ action: 'examly_play_video' }, '*'); } catch (e) {}
    });
  }

  // =================================================================
  //  POPUP → CONTENT MESSAGE HANDLER
  // =================================================================
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!isTop) return;

    if (msg.action === 'start_automation') {
      if (window.examlyRunning) {
        sendResponse({ status: '⚠️ Already running!' });
        return false;
      }
      window.examlyRunning = true;
      const types    = msg.types || ['video', 'mcq', 'coding'];
      const doVideo  = types.includes('video');
      const doMCQ    = types.includes('mcq');
      const doCoding = types.includes('coding');
      sendResponse({ status: `🚀 Started: ${types.join(' + ')}` });
      runAutomation(doVideo, doMCQ, doCoding).catch(e => warn('Error:', e));
      return false;
    }

    if (msg.action === 'inspect_page') {
      sendResponse({ htmlSnippet: document.body.innerHTML.slice(0, 8000) });
      return true;
    }
  });

  // =================================================================
  //  MODULE TYPE PRE-DETECTION FROM TEXT
  //  PA = Practice Assessment (MCQ), FA = Final Assessment (MCQ)
  //  Returns: 'video' | 'mcq' | 'coding' | null
  // =================================================================
  function guessModuleType(mod) {
    const raw = (mod.innerText || '').toUpperCase();

    // ── Explicit video keywords ──
    if (/\bVIDEO\b/.test(raw))   return 'video';
    if (/\bLECTURE\b/.test(raw)) return 'video';
    if (/\bWATCH\b/.test(raw))   return 'video';

    // ── Explicit MCQ / assessment keywords ──
    if (/\bMCQ\b/.test(raw))     return 'mcq';
    // PA = Practice Assessment, FA = Final Assessment (standalone 2-letter words)
    if (/\bPA\b/.test(raw))      return 'mcq';
    if (/\bFA\b/.test(raw))      return 'mcq';
    if (/\bQUIZ\b/.test(raw))    return 'mcq';
    if (/PRACTICE\s*(ASSESS|TEST|QUIZ|EXAM)/.test(raw)) return 'mcq';
    if (/FINAL\s*(ASSESS|TEST|QUIZ|EXAM)/.test(raw))    return 'mcq';
    if (/ASSESSMENT/.test(raw))  return 'mcq';
    if (/\bTEST\b/.test(raw) && !/CODING/.test(raw)) return 'mcq';

    // ── Explicit coding keywords ──
    if (/\bCODING\b/.test(raw))       return 'coding';
    if (/\bPROGRAMMING\b/.test(raw))  return 'coding';
    if (/\bCODE\b/.test(raw))         return 'coding';
    if (/\bLAB\b/.test(raw))          return 'coding';
    if (/\bPROBLEM\b/.test(raw))      return 'coding';

    return null; // unknown — detect after clicking
  }

  // =================================================================
  //  MAIN AUTOMATION LOOP
  // =================================================================
  async function runAutomation(doVideo, doMCQ, doCoding) {
    showToast('🤖 Examly AI v5 started!');
    log('Running:', { doVideo, doMCQ, doCoding });
    window.examlyDone = window.examlyDone || new Set();

    await expandFolders();
    await sleep(300);

    let idleLoops = 0;

    while (window.examlyRunning) {
      const mods = findModules();

      if (mods.length === 0) {
        await expandFolders();
        await sleep(400);
        const mods2 = findModules();
        if (mods2.length === 0) {
          idleLoops++;
          if (idleLoops >= 3) {
            showToast('🎉 All done! Automation complete.');
            break;
          }
          await sleep(1500);
          continue;
        }
        idleLoops = 0;
      }

      idleLoops = 0;
      const mod = mods[0];
      const key = moduleKey(mod);

      // ── Pre-check module type from its label text ─────────────────
      const preType = guessModuleType(mod);
      log('Module pre-type:', preType, '|', mod.innerText?.trim().slice(0, 60));

      // Skip if user hasn't enabled this type
      if (preType === 'video' && !doVideo) {
        log('⏭ Skipping video module (Video not selected)');
        window.examlyDone.add(key);
        await sleep(200);
        continue;
      }
      if (preType === 'mcq' && !doMCQ) {
        log('⏭ Skipping MCQ/PA/FA module (MCQ not selected)');
        showToast('⏭ Skipping MCQ/Assessment…');
        window.examlyDone.add(key);
        await sleep(200);
        continue;
      }
      if (preType === 'coding' && !doCoding) {
        log('⏭ Skipping coding module (Coding not selected)');
        window.examlyDone.add(key);
        await sleep(200);
        continue;
      }

      // Mark as done and click in
      window.examlyDone.add(key);
      log('▶ Clicking module:', mod.innerText?.trim().slice(0, 60));
      showToast('🔍 Opening module…');

      mod.scrollIntoView({ behavior: 'smooth', block: 'center' });
      await sleep(300);
      await aggressiveClick(mod);
      await sleep(200);
      const inner = mod.querySelector('a, button, [role="button"], span.t-cursor-pointer, div.t-cursor-pointer');
      if (inner) await aggressiveClick(inner);

      // Reset video state
      videoFound = false; videoFinished = false;

      // Detect what loaded (10 second timeout)
      const pageType = await detectPageType(10000);
      log('Detected page type:', pageType);

      if (pageType === 'test') {
        if (!doMCQ && !doCoding) {
          log('Test found but MCQ+Coding both disabled — skipping.');
          await sleep(400);
          continue;
        }
        showToast('📋 Test detected! Starting…');
        await handleTest(doMCQ, doCoding);
        await sleep(800);

      } else if (pageType === 'video') {
        if (!doVideo) {
          log('Video found but Video mode disabled — skipping.');
          await sleep(400);
          continue;
        }
        showToast('▶️ Watching video at 2× speed…');
        await watchVideo();

      } else if (pageType === 'mcq_skip') {
        // MCQ detected but user didn't select MCQ
        log('MCQ test detected, MCQ disabled — skipping.');
        showToast('⏭ MCQ test — skipping…');
        await sleep(400);
        // Try to go back
        await goBack();

      } else {
        log('Nothing detected — skipping.');
        await sleep(400);
      }
    }

    window.examlyRunning = false;
  }

  // =================================================================
  //  PAGE TYPE DETECTION
  // =================================================================
  async function detectPageType(timeoutMs) {
    const deadline = Date.now() + timeoutMs;

    while (Date.now() < deadline) {
      // Check video first (fastest)
      pingVideo();
      if (videoFound) return 'video';

      // Check for test buttons
      const ti = testIndicator();
      if (ti) {
        log('Test indicator:', ti);
        return 'test';
      }

      // Retake button
      const retake = findVisibleBtn(['RETAKE TEST', 'RETAKE', 'REATTEMPT', 'RETRY']);
      if (retake) {
        log('Retake button — clicking…');
        await aggressiveClick(retake);
        await sleep(1500);
        continue;
      }

      await sleep(400);
    }

    if (videoFound)      return 'video';
    if (testIndicator()) return 'test';
    return null;
  }

  // =================================================================
  //  TEST INDICATOR
  // =================================================================
  function testIndicator() {
    if (document.querySelector('#tt-header-submit'))     return '#tt-header-submit';
    if (document.querySelector('#tt-start-accept'))      return '#tt-start-accept';
    if (document.querySelector('testtaking-playground')) return 'testtaking-playground';
    if (document.querySelector('app-monaco-editor'))     return 'app-monaco-editor';
    if (document.querySelector('.monaco-editor'))        return '.monaco-editor';
    if (document.querySelector('content-right'))         return 'content-right';

    const all = Array.from(document.querySelectorAll('button, a, div, span'));
    for (const el of all) {
      if (!el.offsetParent) continue;
      const t = (el.innerText || '').trim().toUpperCase();
      if (t === 'TAKE TEST' || t === 'START TEST' || t === 'BEGIN TEST') return 'btn:TAKE TEST';
      if (t === 'TAKE QUIZ' || t === 'START QUIZ')                        return 'btn:TAKE QUIZ';
      if (t === 'RESUME' || t === 'RESUME TEST' || t === 'CONTINUE TEST') return 'btn:RESUME';
      if (t.startsWith('AGREE') && t.includes('PROCEED'))                 return 'btn:AGREE';
      if (t.includes('FULLSCREEN') && !t.includes('EXIT'))                return 'btn:FULLSCREEN';
    }

    if (document.querySelectorAll('input[type="radio"]').length > 0) return 'radio';
    return null;
  }

  // =================================================================
  //  VIDEO WATCHER
  // =================================================================
  async function watchVideo() {
    // Aggressively click play a few times first
    for (let i = 0; i < 6; i++) { pingVideo(); await sleep(400); if (videoFinished) break; }

    let loops = 0;
    while (!videoFinished && loops < 600 && window.examlyRunning) {
      pingVideo();
      await sleep(1000);
      loops++;
      if (loops % 20 === 0) showToast(`▶️ Video: ${Math.round(loops / 60)}min…`);
    }
    showToast('✅ Video done!');
    await sleep(400);
  }

  // =================================================================
  //  GO BACK — navigate back to course listing
  // =================================================================
  async function goBack() {
    const backBtn = findBtnWhere(b => {
      const t = (b.innerText || '').trim().toUpperCase();
      return b.offsetParent && (t === 'BACK' || t === 'GO BACK' || t === 'EXIT' || t === 'CLOSE' ||
        t.includes('BACK') || t.includes('EXIT'));
    });
    if (backBtn) { await aggressiveClick(backBtn); await sleep(1000); return; }
    try { window.history.back(); } catch (e) {}
    await sleep(1000);
  }

  // =================================================================
  //  FIND YES / OK / CONFIRM BUTTON — simple & reliable
  // =================================================================
  function findYesOkButton() {
    // 1. Explicit ID/Class checks that are known to be confirm buttons
    const explicitBtn = document.querySelector('#confirm-submit, button.primary-btn-color:not(#tt-header-submit)');
    if (explicitBtn && explicitBtn.offsetParent) {
      // Exclude the main submit header button just in case
      const t = (explicitBtn.innerText || '').trim().toUpperCase();
      if (!t.includes('TEST') || t.includes('SUBMIT') || t.includes('END')) {
        return explicitBtn;
      }
    }

    // 2. Search ALL buttons + inputs that are visible
    const all = Array.from(document.querySelectorAll(
      'button, [role="button"], input[type="button"], input[type="submit"], a.btn, .btn'
    ));
    return all.find(b => {
      if (!b.offsetParent) return false;
      const t = (b.innerText || b.value || b.textContent || '').trim().toUpperCase();
      // Skip the main question screen header submit button
      if (b.id === 'tt-header-submit') return false;
      
      return (
        t === 'YES'         ||
        t === 'OK'          ||
        t === 'OKAY'        ||
        t === 'CONFIRM'     ||
        t === 'YES, SUBMIT' ||
        t === 'YES, EXIT'   ||
        t === 'YES, END'    ||
        t === 'END TEST'    ||
        t === 'PROCEED'     ||
        t === 'FINISH'      ||
        t === 'DONE'        ||
        t === 'SUBMIT'      ||
        t === 'SUBMIT TEST' ||
        t === 'END'         ||
        (t.startsWith('YES') && t.length < 30) ||
        (t.includes('CONFIRM') && t.length < 40) ||
        (t.includes('SUBMIT') && t.length < 30)
      );
    }) || null;
  }

  // =================================================================
  //  AUTO-CLICK ANY YES/OK dialog that is visible
  // =================================================================
  async function autoClickYesOk() {
    const btn = findYesOkButton();
    if (btn) {
      log('Auto-confirming dialog…');
      showToast('✅ Auto-clicking YES/OK…');
      await aggressiveClick(btn);
      return true;
    }
    return false;
  }

  // =================================================================
  //  TEST HANDLER
  // =================================================================
  async function handleTest(doMCQ, doCoding) {
    // Background: dismiss tab-switch + "code not submitted" popups
    const dismisser = setInterval(async () => {
      const okay = document.querySelector('#tt-playground-alert-accept') ||
        findBtnWhere(b => {
          const t = (b.innerText || '').trim().toUpperCase();
          return b.offsetParent && (t === 'OKAY' || t === 'OK') &&
            document.body.innerText.includes('Tab switching');
        });
      if (okay?.offsetParent) { await aggressiveClick(okay); return; }

      if (document.body.innerText.toLowerCase().includes('not submitted')) {
        const skip = findBtnWhere(b => {
          const t = (b.innerText || '').trim().toUpperCase();
          return b.offsetParent && (t === 'SKIP' || t.startsWith('SKIP'));
        });
        if (skip) await aggressiveClick(skip);
      }
    }, 600);

    let loops = 0;
    let noProgressCnt = 0;
    const MAX_NO_PROGRESS = 25; // ~50 seconds

    try {
      while (window.examlyRunning) {
        loops++;
        if (loops > 500) { log('Safety limit.'); break; }

        // ── P0: Tab-switch alert ──────────────────────────────────
        const alert0 = document.querySelector('#tt-playground-alert-accept') ||
          findBtnWhere(b => {
            const t = (b.innerText || '').trim().toUpperCase();
            return b.offsetParent && (t === 'OKAY' || t === 'OK') &&
              document.body.innerText.includes('Tab switching');
          });
        if (alert0?.offsetParent) {
          await aggressiveClick(alert0);
          noProgressCnt = 0;
          await sleep(1000);
          continue;
        }

        // ── P1: YES/OK/CONFIRM dialogs (handle FIRST — highest priority) ──
        const yesOk = findYesOkButton();
        if (yesOk) {
          log('YES/OK dialog found — clicking…');
          await aggressiveClick(yesOk);
          noProgressCnt = 0;
          await sleep(1500);
          continue;
        }

        // ── P2: Agree & Proceed ───────────────────────────────────
        const agree = document.querySelector('#tt-start-accept') ||
          findBtnWhere(b => {
            const t = (b.innerText || '').trim().toUpperCase();
            return b.offsetParent && (
              t === 'AGREE & PROCEED' || t === 'AGREE AND PROCEED' ||
              (t.includes('AGREE') && t.includes('PROCEED'))
            );
          });
        if (agree?.offsetParent) {
          const cb = document.querySelector('input[type="checkbox"]');
          if (cb && !cb.checked) { await aggressiveClick(cb); await sleep(400); }
          log('Clicking Agree & Proceed…');
          showToast('✅ Agreeing to terms…');
          await aggressiveClick(agree);
          noProgressCnt = 0;
          await sleep(4000);
          continue;
        }

        // ── P3: Take Test / Start Test / Take Quiz ────────────────
        const take = findBtnWhere(b => {
          const t = (b.innerText || '').trim().toUpperCase();
          return b.offsetParent && (
            t === 'TAKE TEST'  || t === 'START TEST'  ||
            t === 'BEGIN TEST' || t === 'TAKE QUIZ'   ||
            t === 'START QUIZ' || t === 'START'
          );
        });
        if (take) {
          // If only coding is enabled and this looks like pure MCQ, skip
          if (!doMCQ && !doCoding) {
            log('Take Test found but neither MCQ nor Coding enabled — aborting.');
            break;
          }
          log('Auto-clicking Take Test…');
          showToast('📋 Clicking Take Test…');
          await aggressiveClick(take);
          noProgressCnt = 0;
          await sleep(3000);
          continue;
        }

        // ── P4: Enable Fullscreen ─────────────────────────────────
        const fs = findBtnWhere(b => {
          const t = (b.innerText || '').trim().toUpperCase();
          return b.offsetParent && (
            t === 'ENABLE FULLSCREEN' || t === 'ENABLE FULL SCREEN' ||
            (t.includes('FULLSCREEN') && !t.includes('EXIT'))
          );
        });
        if (fs) {
          log('Clicking Enable Fullscreen…');
          await aggressiveClick(fs);
          noProgressCnt = 0;
          await sleep(2000);
          continue;
        }

        // ── P5: Resume / Continue ─────────────────────────────────
        const resume = findBtnWhere(b => {
          const t = (b.innerText || '').trim().toUpperCase();
          return b.offsetParent && (
            t === 'RESUME'      || t === 'RESUME TEST'  ||
            t === 'CONTINUE'    || t === 'CONTINUE TEST' ||
            t.includes('RESUME') || t.includes('CONTINUE TEST')
          );
        });
        if (resume) {
          log('Auto-clicking Resume…');
          showToast('▶️ Clicking Resume…');
          await aggressiveClick(resume);
          noProgressCnt = 0;
          await sleep(3000);
          continue;
        }

        // ── P6: Retake ────────────────────────────────────────────
        const retake = findVisibleBtn(['RETAKE TEST', 'RETAKE', 'REATTEMPT', 'RETRY']);
        if (retake) {
          log('Auto-clicking Retake…');
          showToast('🔄 Clicking Retake…');
          await aggressiveClick(retake);
          noProgressCnt = 0;
          await sleep(3000);
          continue;
        }

        // ── Check if we're on the question screen ─────────────────
        const submitBtn = document.querySelector('#tt-header-submit');
        if (!submitBtn) {
          noProgressCnt++;
          log(`Waiting for question screen… (${noProgressCnt}/${MAX_NO_PROGRESS})`);
          if (noProgressCnt >= MAX_NO_PROGRESS) {
            log('No question screen — exiting test handler.');
            break;
          }
          await sleep(2000);
          continue;
        }

        noProgressCnt = 0;

        // Identify question type
        const radios   = Array.from(document.querySelectorAll('input[type="radio"], [role="radio"]'));
        const isMonaco = !!(
          document.querySelector('.monaco-editor') ||
          document.querySelector('app-monaco-editor') ||
          document.querySelector('content-right')
        );

        if (radios.length > 0 && !isMonaco) {
          // ── MCQ question ─────────────────────────────────────────
          if (!doMCQ) {
            // MCQ not wanted — navigate past this question without answering
            log('MCQ question — MCQ disabled, skipping…');
            showToast('⏭ Skipping MCQ question…');
            const done = await moveToNextQuestion(submitBtn, true);
            if (done) break;
          } else {
            const done = await handleMCQ(submitBtn);
            if (done) break;
          }

        } else if (isMonaco) {
          // ── Coding question ───────────────────────────────────────
          if (!doCoding) {
            log('Coding question — Coding disabled, skipping…');
            const done = await moveToNextQuestion(submitBtn, true);
            if (done) break;
          } else {
            const done = await handleCoding(submitBtn);
            if (done) break;
          }

        } else {
          // Question type not loaded yet
          await sleep(1500);
        }
      }
    } finally {
      clearInterval(dismisser);
    }

    showToast('✅ Test section done!');
    await sleep(800);
    await closeTestPage();
  }

  // =================================================================
  //  MCQ HANDLER — AI picks the correct answer
  // =================================================================
  async function handleMCQ(submitBtn) {
    log('MCQ question — asking AI…');
    showToast('📝 Answering MCQ with AI…');

    const playground =
      document.querySelector('testtaking-playground') ||
      document.querySelector('[class*="question-container"]') ||
      document.querySelector('[class*="question"]') ||
      document.body;

    // Gather all visible option texts
    const radioContainers = Array.from(document.querySelectorAll(
      'label, [class*="option"], [class*="choice"], [role="radio"], li[class*="answer"]'
    )).filter(el => el.offsetParent);
    const optionTexts = radioContainers.map(el => (el.innerText || '').trim()).filter(t => t.length > 0);

    const context = playground.innerText?.slice(0, 3000) || '';

    const prompt = [
      'You are an expert solving a multiple-choice exam question.',
      'Read the following question page content carefully:',
      '',
      context,
      '',
      optionTexts.length > 0
        ? 'The answer options are:\n' + optionTexts.map((t, i) => `${i + 1}. ${t}`).join('\n')
        : '',
      '',
      'INSTRUCTIONS:',
      '- Analyze the question carefully and select ONLY the correct answer.',
      '- Reply with ONLY the exact text of the correct option (copy it exactly as shown).',
      '- Do NOT include option numbers (1., 2., A., B. etc.).',
      '- Do NOT include any explanation.',
      '- If multiple correct answers, separate with |||',
    ].join('\n');

    const answer = await askAI(prompt);
    log('AI answered:', answer);

    let clicked = false;

    if (answer) {
      const answers = answer.split('|||').map(s => s.trim().toLowerCase());

      // Strategy 1: Exact label match
      const allLabels = Array.from(document.querySelectorAll(
        'label, [class*="option-text"], [class*="choice-text"], [class*="answer-text"]'
      ));
      for (const label of allLabels) {
        if (!label.offsetParent) continue;
        const txt = (label.innerText || '').trim().toLowerCase();
        if (txt && answers.some(a => txt === a)) {
          await aggressiveClick(label);
          const radio = label.querySelector('input[type="radio"]') ||
            document.getElementById(label.getAttribute('for'));
          if (radio) await aggressiveClick(radio);
          clicked = true;
          log('✅ Exact label match:', txt.slice(0, 60));
          break;
        }
      }

      // Strategy 2: Radio parent text match
      if (!clicked) {
        const allRadios = Array.from(document.querySelectorAll('input[type="radio"], [role="radio"]'));
        for (const radio of allRadios) {
          const parent = radio.closest('label, [class*="option"], [class*="choice"], li') || radio.parentElement;
          const txt = (parent?.innerText || '').trim().toLowerCase();
          if (txt && answers.some(a => txt === a || txt.includes(a) || a.includes(txt.slice(0, 30)))) {
            await aggressiveClick(radio);
            if (parent) await aggressiveClick(parent);
            clicked = true;
            log('✅ Radio parent match:', txt.slice(0, 60));
            break;
          }
        }
      }

      // Strategy 3: Any element partial match
      if (!clicked) {
        const allEls = Array.from(document.querySelectorAll('*'));
        for (const el of allEls) {
          if (el.children.length > 0 || !el.offsetParent) continue;
          const txt = (el.innerText || '').trim().toLowerCase();
          if (txt.length > 1 && answers.some(a => a.length > 3 && txt.includes(a))) {
            await aggressiveClick(el);
            if (el.parentElement) await aggressiveClick(el.parentElement);
            clicked = true;
            log('✅ Partial text match:', txt.slice(0, 60));
            break;
          }
        }
      }

      if (!clicked) {
        warn('No match found — clicking FIRST radio (fallback)');
        const firstRadio = document.querySelector('input[type="radio"], [role="radio"]');
        if (firstRadio) await aggressiveClick(firstRadio);
      }
    } else {
      warn('AI returned nothing — clicking first radio');
      const firstRadio = document.querySelector('input[type="radio"], [role="radio"]');
      if (firstRadio) await aggressiveClick(firstRadio);
    }

    await sleep(600);
    return moveToNextQuestion(submitBtn);
  }

  // =================================================================
  //  NAVIGATE TO NEXT UNATTEMPTED QUESTION OR SUBMIT + END
  //  Returns true if test was submitted and ended
  // =================================================================
  async function moveToNextQuestion(submitBtn, isFastSkip = false) {
    await sleep(isFastSkip ? 100 : 400);

    const unattempted = Array.from(document.querySelectorAll(
      '[aria-labelledby="not-attempted"], [class*="not-attempted"], [title*="Not Attempted"], ' +
      '[class*="unattempt"], [data-status="not-attempted"], [class*="question-nav"][class*="pending"]'
    )).filter(el => el.offsetParent);

    if (unattempted.length > 0) {
      log(`${unattempted.length} unattempted — navigating…`);
      await aggressiveClick(unattempted[0]);
      await sleep(isFastSkip ? 300 : 1800);
      return false;
    }

    // All done — submit
    log('All questions done — submitting…');
    showToast('🏁 Submitting test…');
    await submitWithEnd(submitBtn);
    return true;
  }

  // =================================================================
  //  CODING HANDLER
  // =================================================================
  async function handleCoding(submitBtn) {
    log('Coding question — solving with AI…');
    showToast('💻 AI solving coding question…');

    const leftPane = document.querySelector('content-left, .problem-statement, .description, .left-pane') ||
                     document.querySelector('testtaking-playground') || document.body;
    const questionText = leftPane.innerText?.slice(0, 4000) || '';
    const testCases    = readTestCases();
    const language     = detectLanguage();
    log('Language:', language);

    const MAX_RETRIES = 5;
    let prevCode = '', prevError = '';

    for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
      showToast(`💻 Generating code… attempt ${attempt}/${MAX_RETRIES}`);

      const result = await chrome.runtime.sendMessage({
        action: 'generateCode', question: questionText,
        language, testCases, previousCode: prevCode, previousError: prevError
      });

      if (!result?.success) {
        warn('Code gen failed:', result?.error);
        await sleep(2000);
        continue;
      }

      const code = result.code;
      const pasted = await pasteCode(code);
      if (!pasted) { warn('Could not paste code.'); break; }
      await sleep(800);

      const compileBtn = findBtnWhere(b => {
        const t = (b.innerText || '').trim().toUpperCase();
        return b.offsetParent && (t.includes('COMPILE') || t.includes('RUN') || t === 'RUN CODE');
      });
      if (!compileBtn) { warn('No compile button.'); break; }

      showToast('⚙️ Compiling…');
      await aggressiveClick(compileBtn);
      await sleep(8000);

      const resultArea = document.querySelector(
        '[class*="result"], [class*="output"], #result, .compiler-result, [class*="test-case-result"]'
      );
      const resultText = (resultArea?.innerText || '').toLowerCase();

      const passed = resultText.includes('all test cases passed') || resultText.includes('accepted') ||
                     resultText.includes('correct') || resultText.includes('success');
      const hasError = resultText.includes('error') || resultText.includes('failed') ||
                       resultText.includes('wrong answer');

      if (passed) {
        showToast('✅ All test cases passed!');
        break;
      }
      if (hasError && attempt < MAX_RETRIES) {
        prevCode  = code;
        prevError = resultArea?.innerText?.slice(0, 1000) || 'Error';
        continue;
      }
      break;
    }

    // Submit this coding question
    const submitCodeBtn = findBtnWhere(b => {
      const t = (b.innerText || '').trim().toUpperCase();
      return b.offsetParent && (t === 'SUBMIT' || t === 'SUBMIT CODE' || t === 'FINAL SUBMIT');
    });
    if (submitCodeBtn) {
      log('Submitting code…');
      await aggressiveClick(submitCodeBtn);
      await sleep(2000);
    }

    return moveToNextQuestion(submitBtn);
  }

  // =================================================================
  //  SUBMIT WITH END — types END, retries YES/OK up to 20 times
  // =================================================================
  async function submitWithEnd(submitBtn) {
    await aggressiveClick(submitBtn);
    await sleep(2000);

    // Type END in the confirmation input
    const endField =
      document.querySelector('input[placeholder*="END" i]') ||
      document.querySelector('input[placeholder*="end" i]') ||
      document.querySelector('input[type="text"]');

    if (endField && endField.offsetParent) {
      endField.focus();
      const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
      if (setter) setter.call(endField, 'END');
      else endField.value = 'END';
      
      endField.dispatchEvent(new Event('input',  { bubbles: true }));
      endField.dispatchEvent(new Event('change', { bubbles: true }));
      endField.dispatchEvent(new KeyboardEvent('keydown', { key: 'D', code: 'KeyD', keyCode: 68, charCode: 68, bubbles: true }));
      endField.dispatchEvent(new KeyboardEvent('keyup',   { key: 'D', code: 'KeyD', keyCode: 68, charCode: 68, bubbles: true }));
      
      log('Typed END in confirmation field');
      await sleep(1000); // Give the framework time to enable the YES button
    }

    // Retry YES/OK button click up to 20 times (every 500ms = 10 seconds total)
    let clicked = false;
    for (let i = 0; i < 20; i++) {
      const yesBtn = findYesOkButton();
      if (yesBtn) {
        log(`Clicking YES/OK (attempt ${i + 1})…`);
        showToast('✅ Auto-clicking YES to end test…');
        await aggressiveClick(yesBtn);
        clicked = true;
        await sleep(800);
        // Wait and check if a SECOND confirmation appears
        await sleep(1500);
        const yesBtn2 = findYesOkButton();
        if (yesBtn2) {
          log('Second YES/OK confirmation…');
          await aggressiveClick(yesBtn2);
          await sleep(800);
        }
        break;
      }
      await sleep(500);
    }

    if (!clicked) warn('YES/OK button not found after 20 retries');

    // Final wait for test to close fully
    await sleep(3000);
  }

  // =================================================================
  //  CLOSE TEST PAGE
  // =================================================================
  async function closeTestPage() {
    await sleep(300);
    const exitBtn = findBtnWhere(b => {
      const t = (b.innerText || '').trim().toUpperCase();
      return b.offsetParent && (
        t === 'EXIT' || t === 'GO BACK' || t === 'BACK' || t === 'CLOSE' ||
        t.includes('EXIT') || t.includes('GO BACK')
      );
    });
    if (exitBtn) { await aggressiveClick(exitBtn); await sleep(1500); }
  }

  // =================================================================
  //  PASTE CODE INTO EDITOR
  // =================================================================
  async function pasteCode(code) {
    // 1. Monaco
    const monacoEl = document.querySelector('.monaco-editor .view-lines, .monaco-editor [contenteditable]');
    if (monacoEl) {
      try {
        const container = document.querySelector('.monaco-editor');
        if (container?._monacoEditor) { container._monacoEditor.setValue(code); return true; }
        if (window.monaco?.editor) {
          const eds = window.monaco.editor.getEditors();
          if (eds.length > 0) { eds[0].setValue(code); return true; }
        }
        monacoEl.click(); monacoEl.focus(); await sleep(200);
        monacoEl.dispatchEvent(new KeyboardEvent('keydown', { keyCode: 65, ctrlKey: true, bubbles: true }));
        await sleep(100);
        document.execCommand('insertText', false, code);
        return true;
      } catch (e) { warn('Monaco paste:', e.message); }
    }
    // 2. CodeMirror
    const cm = document.querySelector('.CodeMirror, .cm-editor');
    if (cm) {
      try {
        if (cm.CodeMirror) { cm.CodeMirror.setValue(code); return true; }
        const content = cm.querySelector('.cm-content');
        if (content) { content.focus(); document.execCommand('selectAll'); document.execCommand('insertText', false, code); return true; }
      } catch (e) {}
    }
    // 3. Ace
    if (window.ace) {
      try {
        const aceEl = document.querySelector('.ace_editor');
        if (aceEl) { window.ace.edit(aceEl).setValue(code, -1); return true; }
      } catch (e) {}
    }
    // 4. Textarea
    const ta = document.querySelector('textarea[class*="code"], textarea[class*="editor"], textarea');
    if (ta) {
      const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value')?.set;
      if (setter) setter.call(ta, code);
      ta.dispatchEvent(new Event('input', { bubbles: true }));
      ta.dispatchEvent(new Event('change', { bubbles: true }));
      return true;
    }
    // 5. contenteditable
    const ce = document.querySelector('[contenteditable="true"]');
    if (ce) {
      ce.focus();
      document.execCommand('selectAll');
      document.execCommand('insertText', false, code);
      return true;
    }
    return false;
  }

  // =================================================================
  //  EXPAND ALL FOLDERS
  // =================================================================
  async function expandFolders() {
    log('Expanding folders…');
    let expanded = false;

    for (const el of document.querySelectorAll('[aria-expanded="false"]')) {
      if (!el.offsetParent) continue;
      el.click(); expanded = true; await sleep(50);
    }
    for (const el of document.querySelectorAll(
      '.modpointer, [class*="folder"], [class*="section-header"], [class*="accordion"], [class*="collapse"]'
    )) {
      if (!el.offsetParent) continue;
      const html = el.innerHTML.toLowerCase();
      if ((html.includes('down') || html.includes('chevron') || html.includes('expand')) && !html.includes('up')) {
        el.click(); expanded = true; await sleep(50);
      }
    }
    for (const el of document.querySelectorAll('[data-collapsed="true"], [data-open="false"], [data-expanded="false"]')) {
      if (!el.offsetParent) continue;
      el.click(); expanded = true; await sleep(50);
    }

    if (expanded) { await sleep(200); await expandFolders(); }
  }

  // =================================================================
  //  MODULE DISCOVERY
  // =================================================================
  function findModules() {
    const all      = Array.from(document.querySelectorAll('*'));
    const withText = all.filter(el => el.textContent?.includes('Start :'));
    const deepest  = withText.filter(el => !withText.some(o => o !== el && el.contains(o)));

    const cards = deepest.map(el => {
      let card = el;
      for (let i = 0; i < 3; i++) {
        if (card.parentElement && card.parentElement.tagName !== 'BODY') card = card.parentElement;
      }
      return card;
    });

    const unique = [...new Set(cards)].filter(el => {
      if (!el.innerText) return false;
      return !window.examlyDone.has(moduleKey(el));
    });

    unique.sort((a, b) => a.getBoundingClientRect().top - b.getBoundingClientRect().top);
    return unique;
  }

  function moduleKey(el) {
    let txt = (el.innerText || '').toUpperCase();
    const si = txt.indexOf('START :');
    if (si !== -1) txt = txt.slice(0, si);
    return txt
      .replace(/\d+%/g, '')
      .replace(/\d+:\d+/g, '')
      .replace(/COMPLETED|ATTEMPT|SCORE|STATUS|VIDEO|QUIZ|MCQ/g, '')
      .replace(/[^A-Z0-9]/g, '')
      .slice(0, 80);
  }

  // =================================================================
  //  LANGUAGE DETECTION
  // =================================================================
  function detectLanguage() {
    for (const sel of ['select[class*="lang"]', '[class*="language-select"] select', '#language-select', 'select[id*="lang"]', 'select']) {
      const el = document.querySelector(sel);
      if (el?.value) return el.value.toLowerCase();
    }
    const la = document.querySelector('[data-language]');
    if (la) return la.dataset.language.toLowerCase();
    const tab = document.querySelector('.lang-tab.active, .language-tab.active');
    if (tab) return tab.innerText.trim().toLowerCase();
    const body = document.body.innerText.toLowerCase();
    if (/\bpython\b/.test(body))     return 'python';
    if (/\bjava\b/.test(body))       return 'java';
    if (/\bc\+\+\b|cpp/.test(body))  return 'cpp';
    if (/\bjavascript\b/.test(body)) return 'javascript';
    if (/\bc#|csharp/.test(body))    return 'csharp';
    if (/\bc\b/.test(body))          return 'c';
    return 'java';
  }

  // =================================================================
  //  READ TEST CASES
  // =================================================================
  function readTestCases() {
    const cases = [];
    const ins  = document.querySelectorAll('[class*="sample-input"],[class*="input-box"],[class*="test-input"]');
    const outs = document.querySelectorAll('[class*="sample-output"],[class*="output-box"],[class*="test-output"]');
    const n = Math.min(ins.length, outs.length);
    for (let i = 0; i < n; i++) {
      const ip = ins[i].innerText?.trim(), op = outs[i].innerText?.trim();
      if (ip && op) cases.push({ input: ip, output: op });
    }
    if (cases.length === 0) {
      const pres = [...document.querySelectorAll('pre')].map(p => p.innerText.trim()).filter(Boolean);
      for (let i = 0; i + 1 < pres.length; i += 2) cases.push({ input: pres[i], output: pres[i + 1] });
    }
    return cases;
  }

  // =================================================================
  //  AI CALL (MCQ answering from content script)
  // =================================================================
  async function askAI(prompt) {
    return new Promise(resolve => {
      chrome.storage.local.get(['geminiApiKey', 'geminiModel', 'openrouterApiKey', 'openrouterModel', 'apiProvider'], async r => {
        const provider = r.apiProvider || 'gemini';

        if (provider === 'openrouter') {
          const key = (r.openrouterApiKey || '').trim();
          const model = (r.openrouterModel || 'openai/gpt-4o-mini').trim();
          if (!key) { resolve(null); return; }
          try {
            const resp = await fetch('https://openrouter.ai/api/v1/chat/completions', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${key}`, 'HTTP-Referer': 'https://examly.io', 'X-Title': 'Examly AI' },
              body: JSON.stringify({ model, messages: [{ role: 'user', content: prompt }], temperature: 0.1 })
            });
            const data = await resp.json();
            resolve(data?.choices?.[0]?.message?.content?.trim() || null);
          } catch (e) { warn('OpenRouter error:', e); resolve(null); }
          return;
        }

        const key = (r.geminiApiKey || '').trim();
        const model = (r.geminiModel || 'gemini-2.0-flash').trim();
        if (!key) { resolve(null); return; }
        try {
          const resp = await fetch(
            `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`,
            { method: 'POST', headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { temperature: 0.1, maxOutputTokens: 2048 } }) }
          );
          const data = await resp.json();
          const text = data?.candidates?.[0]?.content?.parts?.[0]?.text?.trim();
          resolve(text ? text.replace(/```[\s\S]*?```/g, s => s.replace(/```\w*\n?/, '').replace(/```$/, '').trim()) : null);
        } catch (e) { warn('Gemini error:', e); resolve(null); }
      });
    });
  }

  // =================================================================
  //  UTILITIES
  // =================================================================
  function findVisibleBtn(textList) {
    const upper = textList.map(t => t.toUpperCase());
    return Array.from(document.querySelectorAll('button, a, div, span')).find(el => {
      if (!el.offsetParent) return false;
      return upper.includes((el.innerText || '').trim().toUpperCase());
    }) || null;
  }

  function findBtnWhere(pred) {
    return Array.from(document.querySelectorAll('button, a, div, span')).find(pred) || null;
  }

  // =================================================================
  //  TOAST NOTIFICATION
  // =================================================================
  function showToast(msg) {
    log(msg);
    let t = document.getElementById('_examlyToast');
    if (!t) {
      t = document.createElement('div');
      t.id = '_examlyToast';
      Object.assign(t.style, {
        position: 'fixed', bottom: '20px', right: '20px', zIndex: '2147483647',
        background: 'linear-gradient(135deg,#0f0f1e,#1a1050)',
        color: '#00e878', border: '1.5px solid #00e878', borderRadius: '12px',
        padding: '10px 18px', fontFamily: 'Inter,Segoe UI,monospace',
        fontSize: '13px', fontWeight: '700',
        boxShadow: '0 4px 20px rgba(0,232,120,0.3)',
        maxWidth: '320px', wordWrap: 'break-word',
        transition: 'opacity 0.3s', pointerEvents: 'none'
      });
      document.body.appendChild(t);
    }
    clearTimeout(t._timer);
    t.style.opacity = '1';
    t.textContent   = msg;
    t._timer = setTimeout(() => { t.style.opacity = '0'; }, 5000);
  }

  log('Content script v5.0.0 loaded ✅');
}
