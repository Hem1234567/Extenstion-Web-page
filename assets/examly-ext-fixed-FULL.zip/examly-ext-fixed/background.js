// =================================================================
//  background.js – Examly AI Automation v3.2.0
//  Service worker: handles generateCode API calls
//  Supports: Gemini (default) and OpenRouter
// =================================================================

'use strict';

chrome.runtime.onMessage.addListener((req, _sender, sendResponse) => {

  if (req.action === 'generateCode') {
    generateCode(req)
      .then(r  => sendResponse(r))
      .catch(e => sendResponse({ success: false, error: e.message }));
    return true;
  }

  if (req.action === 'getSettings') {
    chrome.storage.local.get(
      ['geminiApiKey', 'geminiModel', 'openrouterApiKey', 'openrouterModel', 'apiProvider', 'automationTypes'],
      r => sendResponse(r)
    );
    return true;
  }
});

// =================================================================
//  CODE GENERATION
// =================================================================
async function generateCode({ question, language, testCases, previousCode, previousError }) {
  const r        = await getStore(['geminiApiKey', 'geminiModel', 'openrouterApiKey', 'openrouterModel', 'apiProvider']);
  const provider = r.apiProvider || 'gemini';
  const prompt   = buildPrompt(question, language, testCases, previousCode, previousError);

  if (provider === 'openrouter') {
    const key   = (r.openrouterApiKey  || '').trim();
    const model = (r.openrouterModel   || 'openai/gpt-4o-mini').trim();
    if (!key) return { success: false, error: 'No OpenRouter API key in settings.' };
    try {
      const code = await callOpenRouter(key, model, prompt);
      return { success: true, code };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }

  // Default: Gemini
  const key   = (r.geminiApiKey  || '').trim();
  const model = (r.geminiModel   || 'gemini-2.0-flash').trim();
  if (!key) return { success: false, error: 'No Gemini API key in settings.' };
  try {
    const code = await callGemini(key, model, prompt);
    return { success: true, code };
  } catch (e) {
    return { success: false, error: e.message };
  }
}

// =================================================================
//  GEMINI API
// =================================================================
async function callGemini(apiKey, model, prompt) {
  const url  = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
  const resp = await fetch(url, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents:         [{ parts: [{ text: prompt }] }],
      generationConfig: { temperature: 0.05, maxOutputTokens: 4096, topP: 0.8 }
    })
  });
  if (!resp.ok) throw new Error(`Gemini ${resp.status}: ${(await resp.text()).slice(0, 200)}`);
  const data = await resp.json();
  const raw  = data?.candidates?.[0]?.content?.parts?.[0]?.text ?? '';
  if (!raw) throw new Error('Gemini returned empty response.');
  return stripFence(raw);
}

// =================================================================
//  OPENROUTER API
// =================================================================
async function callOpenRouter(apiKey, model, prompt) {
  const resp = await fetch('https://openrouter.ai/api/v1/chat/completions', {
    method:  'POST',
    headers: {
      'Content-Type':  'application/json',
      'Authorization': `Bearer ${apiKey}`,
      'HTTP-Referer':  'https://examly.io',
      'X-Title':       'Examly AI Automation'
    },
    body: JSON.stringify({
      model,
      messages:    [{ role: 'user', content: prompt }],
      temperature: 0.05,
      max_tokens:  4096
    })
  });
  if (!resp.ok) throw new Error(`OpenRouter ${resp.status}: ${(await resp.text()).slice(0, 200)}`);
  const data = await resp.json();
  if (data.error) throw new Error(`OpenRouter: ${data.error.message || JSON.stringify(data.error)}`);
  const raw = data?.choices?.[0]?.message?.content ?? '';
  if (!raw) throw new Error('OpenRouter returned empty response.');
  return stripFence(raw);
}

// =================================================================
//  PROMPT BUILDER
// =================================================================
function buildPrompt(question, language, testCases, prevCode, prevError) {
  const lang = normLang(language);

  let p = `You are an expert competitive programmer.
Solve the problem below in ${lang}.

STRICT OUTPUT RULES:
- Output ONLY raw source code. NO explanations. NO markdown fences. NO comments.
- Must read from stdin, write to stdout.
- For Java: class name MUST be "Main" with public static void main(String[] args).
- For Python: use sys.stdin to read input.
- Code must be complete and runnable as-is.

PROBLEM:
${question.trim()}`;

  if (testCases?.length > 0) {
    p += '\n\nSAMPLE TEST CASES:\n';
    testCases.forEach((tc, i) => {
      p += `\nCase ${i + 1}:\nInput:\n${tc.input}\nExpected Output:\n${tc.output}\n`;
    });
    p += '\nYour solution MUST pass all sample cases.';
  }

  if (prevCode && prevError) {
    p += `\n\nPREVIOUS CODE FAILED — FIX IT:
The code below produced an error. Fix ALL issues.

CODE:
${prevCode}

ERROR:
${prevError}

Output ONLY the corrected source code.`;
  }

  return p;
}

// =================================================================
//  HELPERS
// =================================================================
function stripFence(raw) {
  const m = raw.match(/```(?:[a-zA-Z+#]*\n)?([\s\S]*?)```/);
  return m ? m[1].trim() : raw.trim();
}

function normLang(lang) {
  const map = {
    python: 'Python 3', python3: 'Python 3', py: 'Python 3',
    java: 'Java',
    c: 'C',
    cpp: 'C++', 'c++': 'C++',
    javascript: 'JavaScript (Node.js)', js: 'JavaScript (Node.js)',
    typescript: 'TypeScript', ts: 'TypeScript',
    go: 'Go', golang: 'Go',
    ruby: 'Ruby', rb: 'Ruby',
    swift: 'Swift',
    kotlin: 'Kotlin',
    csharp: 'C#', 'c#': 'C#', cs: 'C#',
    rust: 'Rust', rs: 'Rust',
    php: 'PHP',
    scala: 'Scala',
    r: 'R'
  };
  return map[(lang || '').toLowerCase()] ?? (lang || 'Java');
}

function getStore(keys) {
  return new Promise(resolve => chrome.storage.local.get(keys, resolve));
}
