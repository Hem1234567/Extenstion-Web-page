// popup.js – Examly AI Automation v4.0.0

document.addEventListener('DOMContentLoaded', () => {

  // ── Refs ───────────────────────────────────────────────────────
  const goBtn      = document.getElementById('go-btn');
  const fullBtn    = document.getElementById('btn-full');
  const inspectBtn = document.getElementById('inspect-btn');
  const summary    = document.getElementById('summary');
  const dot        = document.getElementById('dot');
  const stxt       = document.getElementById('stxt');
  const badge      = document.getElementById('badge');

  const ptabGem    = document.getElementById('ptab-gem');
  const ptabOr     = document.getElementById('ptab-or');
  const panelGem   = document.getElementById('panel-gem');
  const panelOr    = document.getElementById('panel-or');

  const gemKey     = document.getElementById('gem-key');
  const gemModel   = document.getElementById('gem-model');
  const saveGem    = document.getElementById('save-gem');

  const orKey      = document.getElementById('or-key');
  const orModel    = document.getElementById('or-model');
  const saveOr     = document.getElementById('save-or');

  const modeBtns   = document.querySelectorAll('.mode-btn');

  // ── State ──────────────────────────────────────────────────────
  const on     = new Set();
  let provider = 'gemini';

  // ── Load saved settings ────────────────────────────────────────
  chrome.storage.local.get([
    'geminiApiKey', 'geminiModel',
    'openrouterApiKey', 'openrouterModel',
    'apiProvider', 'automationTypes'
  ], r => {
    provider = r.apiProvider || 'gemini';
    renderTabs();

    if (r.geminiApiKey)     { gemKey.value   = r.geminiApiKey; }
    if (r.geminiModel)      { gemModel.value = r.geminiModel;  }
    if (r.openrouterApiKey) { orKey.value    = r.openrouterApiKey; }
    if (r.openrouterModel)  { orModel.value  = r.openrouterModel;  }

    updateBadge(r);

    (r.automationTypes || []).forEach(t => on.add(t));
    renderModes();
  });

  // ── Provider tab switch ────────────────────────────────────────
  [ptabGem, ptabOr].forEach(tab => {
    tab.addEventListener('click', () => {
      provider = tab.dataset.p;
      chrome.storage.local.set({ apiProvider: provider });
      renderTabs();
      chrome.storage.local.get(['geminiApiKey', 'openrouterApiKey'], updateBadge);
    });
  });

  function renderTabs() {
    ptabGem.className = 'ptab' + (provider === 'gemini'     ? ' gem' : '');
    ptabOr.className  = 'ptab' + (provider === 'openrouter' ? ' or'  : '');
    panelGem.style.display = provider === 'gemini'     ? '' : 'none';
    panelOr.style.display  = provider === 'openrouter' ? '' : 'none';
  }

  function updateBadge(r) {
    const has = provider === 'openrouter' ? !!r.openrouterApiKey : !!r.geminiApiKey;
    badge.classList.toggle('show', has);
  }

  // ── Save Gemini ────────────────────────────────────────────────
  saveGem.addEventListener('click', () => {
    const key = gemKey.value.trim();
    if (!key) { setStatus('⚠️ Paste your Gemini API key first', 'err'); return; }
    const model = gemModel.value.trim() || 'gemini-2.0-flash';
    chrome.storage.local.set({ geminiApiKey: key, geminiModel: model, apiProvider: 'gemini' }, () => {
      provider = 'gemini';
      badge.classList.add('show');
      setStatus(`✅ Gemini saved! Model: ${model}`, 'ready');
      setTimeout(() => setStatus('Ready', 'ready'), 2500);
    });
  });

  // ── Save OpenRouter ───────────────────────────────────────────
  saveOr.addEventListener('click', () => {
    const key = orKey.value.trim();
    if (!key) { setStatus('⚠️ Paste your OpenRouter API key first', 'err'); return; }
    const model = orModel.value.trim() || 'openai/gpt-4o-mini';
    chrome.storage.local.set({ openrouterApiKey: key, openrouterModel: model, apiProvider: 'openrouter' }, () => {
      provider = 'openrouter';
      badge.classList.add('show');
      setStatus(`✅ OpenRouter saved! Model: ${model}`, 'ready');
      setTimeout(() => setStatus('Ready', 'ready'), 2500);
    });
  });

  // ── Mode toggles ───────────────────────────────────────────────
  modeBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const t = btn.dataset.t;
      if (on.has(t)) on.delete(t); else on.add(t);
      renderModes();
      chrome.storage.local.set({ automationTypes: [...on] });
    });
  });

  // ── FULL AUTOMATION button ─────────────────────────────────────
  // Selects ALL modes + immediately starts automation
  if (fullBtn) {
    fullBtn.addEventListener('click', () => {
      on.add('video');
      on.add('mcq');
      on.add('coding');
      renderModes();
      chrome.storage.local.set({ automationTypes: [...on] });
      fullBtn.classList.add('pulsing');

      // Check API key requirement and start
      const storKey = provider === 'openrouter' ? 'openrouterApiKey' : 'geminiApiKey';
      chrome.storage.local.get([storKey], r => {
        if (!r[storKey]) {
          const name = provider === 'openrouter' ? 'OpenRouter' : 'Gemini';
          setStatus(`⚠️ Add your ${name} API key for MCQ/Coding`, 'err');
          fullBtn.classList.remove('pulsing');
          return;
        }
        doStart();
      });
    });
  }

  function renderModes() {
    modeBtns.forEach(btn => {
      const t = btn.dataset.t;
      btn.className = 'mode-btn' + (on.has(t) ? ` on-${t}` : '');
    });
    if (on.size === 0) {
      summary.className   = 'summary none';
      summary.textContent = '⚠️ Select at least one';
    } else if (on.size === 3) {
      summary.className   = 'summary active';
      summary.textContent = '✅ Full Automation — All modes';
    } else {
      const labels = { video: '▶️ Video', mcq: '📝 MCQ', coding: '💻 Coding' };
      summary.className   = 'summary active';
      summary.textContent = '✅ ' + [...on].map(t => labels[t]).join(' + ');
    }
  }

  // ── Start automation (manual) ──────────────────────────────────
  goBtn.addEventListener('click', () => {
    if (on.size === 0) { setStatus('⚠️ Select at least one mode!', 'err'); return; }

    // API key required for MCQ and Coding
    if (on.has('mcq') || on.has('coding')) {
      const storKey = provider === 'openrouter' ? 'openrouterApiKey' : 'geminiApiKey';
      chrome.storage.local.get([storKey], r => {
        if (!r[storKey]) {
          const name = provider === 'openrouter' ? 'OpenRouter' : 'Gemini';
          setStatus(`⚠️ Add your ${name} API key for MCQ/Coding`, 'err');
          return;
        }
        doStart();
      });
    } else {
      doStart();
    }
  });

  function doStart() {
    setStatus('🚀 Starting automation…', 'working');
    goBtn.disabled = true;
    if (fullBtn) fullBtn.disabled = true;

    send('start_automation', { types: [...on] }, res => {
      goBtn.disabled = false;
      if (fullBtn) {
        fullBtn.disabled = false;
        fullBtn.classList.remove('pulsing');
      }
      setStatus(res?.status || '✅ Running on page!', 'ready');
    });
  }

  // ── Inspect page ──────────────────────────────────────────────
  inspectBtn.addEventListener('click', () => {
    setStatus('🔍 Copying HTML…', 'working');
    send('inspect_page', {}, res => {
      if (res?.htmlSnippet) {
        navigator.clipboard.writeText(res.htmlSnippet)
          .then(() => setStatus('📋 HTML copied!', 'ready'))
          .catch(() => setStatus('Copy failed', 'err'));
      } else {
        setStatus('Could not get HTML', 'err');
      }
    });
  });

  // ── Send message to active tab (inject if needed) ─────────────
  function send(action, payload, cb) {
    chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
      const tab = tabs[0];
      if (!tab?.id) { setStatus('No active tab', 'err'); return; }

      const msg = { action, ...payload };

      chrome.tabs.sendMessage(tab.id, msg, resp => {
        if (chrome.runtime.lastError) {
          // Script not injected yet — inject it
          chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] }, () => {
            if (chrome.runtime.lastError) {
              setStatus('❌ Cannot inject on this page', 'err');
              if (cb) cb(null);
              return;
            }
            setTimeout(() => {
              chrome.tabs.sendMessage(tab.id, msg, r2 => {
                if (chrome.runtime.lastError) { setStatus('❌ Injection failed', 'err'); if (cb) cb(null); }
                else if (cb) cb(r2);
              });
            }, 600);
          });
        } else {
          if (cb) cb(resp);
        }
      });
    });
  }

  // ── Status helper ─────────────────────────────────────────────
  function setStatus(text, state) {
    stxt.textContent = text;
    dot.className    = 'dot ' + (state || 'ready');
    goBtn.disabled   = (state === 'working');
  }
});
