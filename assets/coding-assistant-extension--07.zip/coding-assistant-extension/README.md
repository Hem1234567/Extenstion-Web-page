# CodeSolver AI - Chrome Extension

## 🚀 What It Does
- **Detects** coding problems and MCQ questions on any webpage
- **Solves** them using your OpenRouter API key (any AI model)
- **Pastes** the answer directly into the code editor on the page
- Works with **LeetCode, HackerRank, CodeChef, Codeforces, GeeksForGeeks, HackerEarth**, and more

---

## 📦 Installation (Chrome)

1. Open Chrome and go to `chrome://extensions/`
2. Enable **Developer Mode** (toggle in top-right corner)
3. Click **Load unpacked**
4. Select the `coding-assistant-extension` folder
5. The ⚡ icon will appear in your toolbar

---

## ⚙️ Setup

1. Click the ⚡ extension icon (or press `Ctrl+P`)
2. Go to the **Settings** tab
3. Paste your **OpenRouter API key** (get one free at https://openrouter.ai)
4. Choose your preferred AI model
5. Click **Save**

---

## 🎯 How to Use

1. Navigate to any coding problem or MCQ page
2. Click the ⚡ icon or press **Ctrl+P**
3. Click **"Scan Page for Question"**
4. The extension will:
   - Extract the question from the page
   - Generate a solution using AI
   - Paste the code directly into the editor
   - Show the answer in the popup

---

## 🧠 Supported Editors

- **Monaco** (LeetCode, HackerEarth)
- **CodeMirror** (HackerRank, Codeforces)
- **ACE Editor** (CodeChef, others)
- Generic `<textarea>` fallbacks

---

## 💡 Tips

- For **MCQ**: The correct option will be highlighted in green with an explanation
- For **Code**: The solution is pasted directly into the editor AND shown in the popup
- If paste fails (editor not detected), copy the code from the popup manually
- Use **DeepSeek Coder** model for best coding accuracy

---

## 🔑 Getting an OpenRouter API Key

1. Go to https://openrouter.ai
2. Sign up for a free account
3. Go to **API Keys** section
4. Create a new key (starts with `sk-or-v1-...`)
5. Some models like Gemini Flash have a free tier!

---

## 📋 Recommended Models

| Model | Best For | Speed |
|-------|----------|-------|
| DeepSeek Coder | Competitive programming | Fast |
| Claude 3.5 Sonnet | Complex problems | Medium |
| GPT-4o | General coding | Medium |
| Gemini Flash 1.5 | Free usage | Very Fast |

---

## ⚠️ Notes

- API key is stored locally in Chrome storage (never sent anywhere except OpenRouter)
- Works on HTTPS pages
- Some platforms may block clipboard/paste — the code is always shown in popup
