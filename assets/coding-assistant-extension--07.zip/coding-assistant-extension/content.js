// content.js - CodeSolver AI Extension
// Handles page content extraction and code editor paste

(function () {
  'use strict';

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === 'getPageContent') {
      sendResponse({ text: getPageText(), title: document.title });
    }
    if (msg.action === 'pasteCode') {
      pasteCodeIntoEditor(msg.code).then(result => sendResponse(result));
      return true; // async
    }
    if (msg.action === 'ping') {
      sendResponse({ ok: true });
    }
    return true;
  });

  // ── Extract visible question text ─────────────────────────────────────────
  function getPageText() {
    const selectors = [
      '[data-track-load="description_content"]',
      '.description__24sA', '.elfjS',
      '.challenge-body-html', '.hackdown-content', '.challenge-text',
      '.problem-statement', '.problem-details-section',
      '.problems_problem_content__Xm_eO',
      '.problem-body', '[class*="question-content"]',
      '[class*="problem-content"]',
      'main', 'article', '.content', '#content'
    ];
    for (const sel of selectors) {
      try {
        const el = document.querySelector(sel);
        if (el && el.innerText && el.innerText.trim().length > 80)
          return el.innerText.trim().substring(0, 12000);
      } catch (_) {}
    }
    return document.body.innerText.substring(0, 12000);
  }

  // ── Master paste function ─────────────────────────────────────────────────
  async function pasteCodeIntoEditor(code) {

    // 1. Monaco Editor (LeetCode, Azure, VSCode web, HackerEarth)
    const monacoResult = tryMonaco(code);
    if (monacoResult.success) return monacoResult;

    // 2. CodeMirror 5 (HackerRank, Codeforces, etc.)
    const cm5Result = tryCodeMirror5(code);
    if (cm5Result.success) return cm5Result;

    // 3. CodeMirror 6 (newer platforms)
    const cm6Result = tryCodeMirror6(code);
    if (cm6Result.success) return cm6Result;

    // 4. ACE Editor (CodeChef, many online judges)
    const aceResult = tryAce(code);
    if (aceResult.success) return aceResult;

    // 5. Generic textarea (largest visible one)
    const taResult = tryTextarea(code);
    if (taResult.success) return taResult;

    // 6. ContentEditable
    const ceResult = tryContentEditable(code);
    if (ceResult.success) return ceResult;

    return { success: false, editor: null, reason: 'No editor found' };
  }

  // ── Monaco ────────────────────────────────────────────────────────────────
  function tryMonaco(code) {
    // Method A: use the global monaco API
    try {
      if (window.monaco && window.monaco.editor) {
        const editors = window.monaco.editor.getEditors();
        if (editors && editors.length > 0) {
          const ed = editors[0];
          const model = ed.getModel();
          if (model) {
            model.setValue(code);
            ed.focus();
            return { success: true, editor: 'Monaco (API)' };
          }
        }
      }
    } catch (_) {}

    // Method B: find textarea inside .monaco-editor and dispatch events
    try {
      const monacoRoot = document.querySelector('.monaco-editor');
      if (monacoRoot) {
        const textarea = monacoRoot.querySelector('textarea.inputarea, textarea');
        if (textarea) {
          textarea.focus();
          // Select all text
          textarea.dispatchEvent(new KeyboardEvent('keydown', { key: 'a', code: 'KeyA', ctrlKey: true, bubbles: true }));
          // Small wait then insert
          setTimeout(() => {
            document.execCommand('selectAll', false, null);
            document.execCommand('insertText', false, code);
          }, 50);
          return { success: true, editor: 'Monaco (textarea)' };
        }
      }
    } catch (_) {}

    // Method C: dispatch keyboard events to simulate typing
    try {
      const monacoEl = document.querySelector('.monaco-editor .view-lines, .monaco-editor');
      if (monacoEl) {
        monacoEl.click();
        monacoEl.focus();
        setTimeout(() => {
          // Ctrl+A to select all
          monacoEl.dispatchEvent(new KeyboardEvent('keydown', { key: 'a', code: 'KeyA', ctrlKey: true, bubbles: true }));
          setTimeout(() => {
            // Try clipboard approach
            const activeEl = document.activeElement;
            if (activeEl && activeEl.tagName === 'TEXTAREA') {
              activeEl.value = code;
              activeEl.dispatchEvent(new Event('input', { bubbles: true }));
            }
          }, 100);
        }, 50);
        return { success: true, editor: 'Monaco (click+keys)' };
      }
    } catch (_) {}

    return { success: false };
  }

  // ── CodeMirror 5 ──────────────────────────────────────────────────────────
  function tryCodeMirror5(code) {
    try {
      // Direct JS object access
      const cmEls = document.querySelectorAll('.CodeMirror');
      for (const el of cmEls) {
        if (el.CodeMirror) {
          el.CodeMirror.setValue(code);
          el.CodeMirror.focus();
          return { success: true, editor: 'CodeMirror 5' };
        }
      }
    } catch (_) {}
    return { success: false };
  }

  // ── CodeMirror 6 ──────────────────────────────────────────────────────────
  function tryCodeMirror6(code) {
    try {
      const cmEl = document.querySelector('.cm-editor .cm-content, .cm-content');
      if (cmEl) {
        cmEl.focus();
        // Select all + replace
        document.execCommand('selectAll', false, null);
        document.execCommand('insertText', false, code);
        return { success: true, editor: 'CodeMirror 6' };
      }
    } catch (_) {}
    return { success: false };
  }

  // ── ACE Editor ────────────────────────────────────────────────────────────
  function tryAce(code) {
    try {
      // Method A: window.ace
      if (window.ace) {
        const aceEls = document.querySelectorAll('.ace_editor');
        for (const el of aceEls) {
          try {
            const editor = window.ace.edit(el);
            editor.setValue(code, -1); // -1 = cursor at start
            editor.focus();
            return { success: true, editor: 'ACE (global)' };
          } catch (_) {}
        }
      }
    } catch (_) {}

    try {
      // Method B: env attribute
      const aceEls = document.querySelectorAll('.ace_editor');
      for (const el of aceEls) {
        if (el.env && el.env.editor) {
          el.env.editor.setValue(code, -1);
          el.env.editor.focus();
          return { success: true, editor: 'ACE (env)' };
        }
      }
    } catch (_) {}

    try {
      // Method C: ACE textarea
      const aceInput = document.querySelector('.ace_text-input');
      if (aceInput) {
        aceInput.focus();
        document.execCommand('selectAll', false, null);
        document.execCommand('insertText', false, code);
        return { success: true, editor: 'ACE (textarea)' };
      }
    } catch (_) {}

    return { success: false };
  }

  // ── Generic Textarea ──────────────────────────────────────────────────────
  function tryTextarea(code) {
    try {
      // Priority: find textareas that look like code editors
      const codeTextareas = document.querySelectorAll(
        'textarea[class*="code"], textarea[id*="code"], textarea[name*="code"], ' +
        'textarea[class*="editor"], textarea[id*="editor"], ' +
        'textarea[class*="solution"], textarea[id*="solution"]'
      );
      if (codeTextareas.length > 0) {
        return setTextarea(codeTextareas[0], code, 'Textarea (code-named)');
      }

      // Fallback: largest visible textarea
      const all = Array.from(document.querySelectorAll('textarea'));
      const visible = all.filter(t => {
        const r = t.getBoundingClientRect();
        return r.width > 50 && r.height > 50;
      });
      if (visible.length === 0) return { success: false };

      const biggest = visible.reduce((a, b) =>
        (a.getBoundingClientRect().width * a.getBoundingClientRect().height) >
        (b.getBoundingClientRect().width * b.getBoundingClientRect().height) ? a : b
      );
      return setTextarea(biggest, code, 'Textarea (largest)');
    } catch (_) {}
    return { success: false };
  }

  function setTextarea(el, code, label) {
    el.focus();
    el.select();
    // Try execCommand first (preserves undo stack)
    const ok = document.execCommand('insertText', false, code);
    if (!ok || el.value !== code) {
      // Direct value set
      const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
      setter.call(el, code);
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
    }
    return { success: true, editor: label };
  }

  // ── ContentEditable ───────────────────────────────────────────────────────
  function tryContentEditable(code) {
    try {
      const ceEls = document.querySelectorAll('[contenteditable="true"]');
      for (const el of ceEls) {
        const r = el.getBoundingClientRect();
        if (r.width > 100 && r.height > 100) {
          el.focus();
          document.execCommand('selectAll', false, null);
          document.execCommand('insertText', false, code);
          return { success: true, editor: 'ContentEditable' };
        }
      }
    } catch (_) {}
    return { success: false };
  }

})();
