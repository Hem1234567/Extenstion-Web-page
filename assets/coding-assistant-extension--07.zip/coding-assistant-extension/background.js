// background.js - CodeSolver AI Extension Service Worker

chrome.runtime.onInstalled.addListener(() => {
  console.log('[CodeSolver AI] Extension installed successfully.');
});

// Handle keyboard shortcut (Ctrl+P is handled via _execute_action in manifest)
// which auto-opens the popup, so no extra code needed here.

// Keep service worker alive for API calls if needed
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'keepAlive') {
    sendResponse({ ok: true });
  }
  return true;
});
