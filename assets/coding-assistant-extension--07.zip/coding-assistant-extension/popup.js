// popup.js - CodeSolver AI Extension

// ─── Tab switching ────────────────────────────────────────────────────────────
document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    tab.classList.add('active');
    document.getElementById(`tab-${tab.dataset.tab}`).classList.add('active');
  });
});

// ─── Load saved settings ──────────────────────────────────────────────────────
chrome.storage.local.get(['apiKey', 'model', 'autoPaste'], (data) => {
  if (data.apiKey) {
    document.getElementById('apiKeyInput').value = data.apiKey;
    document.getElementById('statusDot').classList.add('active');
  }
  if (data.model) document.getElementById('modelSelect').value = data.model;
  if (typeof data.autoPaste !== 'undefined')
    document.getElementById('autoPasteToggle').checked = data.autoPaste;
});

// ─── Settings listeners ───────────────────────────────────────────────────────
document.getElementById('saveKeyBtn').addEventListener('click', () => {
  const key = document.getElementById('apiKeyInput').value.trim();
  if (!key) { showMsg('keyMsg', 'Please enter your API key.', 'error'); return; }
  chrome.storage.local.set({ apiKey: key }, () => {
    document.getElementById('statusDot').classList.add('active');
    showMsg('keyMsg', '✓ API key saved securely.', 'success');
  });
});
document.getElementById('modelSelect').addEventListener('change', e =>
  chrome.storage.local.set({ model: e.target.value }));
document.getElementById('autoPasteToggle').addEventListener('change', e =>
  chrome.storage.local.set({ autoPaste: e.target.checked }));
document.getElementById('clearKeyBtn').addEventListener('click', () => {
  chrome.storage.local.remove('apiKey', () => {
    document.getElementById('apiKeyInput').value = '';
    document.getElementById('statusDot').classList.remove('active');
    showMsg('settingsMsg', 'API key cleared.', 'info');
  });
});

// ─── Copy button ──────────────────────────────────────────────────────────────
document.getElementById('copyBtn').addEventListener('click', () => {
  const code = document.getElementById('codeAnswer').textContent ||
               document.getElementById('textAnswer').textContent;
  navigator.clipboard.writeText(code).then(() => {
    document.getElementById('copyBtn').textContent = '✓ Copied!';
    setTimeout(() => { document.getElementById('copyBtn').textContent = 'Copy'; }, 1500);
  });
});

// ─── Manual paste button ──────────────────────────────────────────────────────
document.getElementById('pasteBtn').addEventListener('click', async () => {
  const code = document.getElementById('codeAnswer').textContent;
  if (!code) return;
  await doPaste(code);
});

// ─── Main scan button ─────────────────────────────────────────────────────────
document.getElementById('scanBtn').addEventListener('click', scanAndSolve);

async function scanAndSolve() {
  const { apiKey, model = 'deepseek/deepseek-chat', autoPaste = true } =
    await chromeGet(['apiKey', 'model', 'autoPaste']);

  if (!apiKey) {
    showMsg('solveMsg', '⚠️ No API key. Go to Settings tab and save your OpenRouter key.', 'error');
    return;
  }

  hideAll();
  setLoader(true, 'Scanning page for questions…');

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    // ── Step 1: extract page content via executeScript (no messaging needed) ──
    const pageText = await runInPage(tab.id, function() {
      const selectors = [
        '[data-track-load="description_content"]',
        '.elfjS', '.description__24sA',
        '.challenge-body-html', '.hackdown-content', '.challenge-text',
        '.problem-statement', '.problem-details-section',
        '.problems_problem_content__Xm_eO', '.problem-body',
        '[class*="question-content"]', '[class*="problem-content"]',
        'main', 'article', '.content', '#content'
      ];
      for (const sel of selectors) {
        try {
          const el = document.querySelector(sel);
          if (el && el.innerText && el.innerText.trim().length > 80)
            return el.innerText.trim().substring(0, 12000);
        } catch(_) {}
      }
      return document.body.innerText.substring(0, 12000);
    });

    if (!pageText || pageText.length < 30) {
      setLoader(false);
      showMsg('solveMsg', '❌ Could not read page content. Try refreshing.', 'error');
      return;
    }

    setLoader(true, 'AI is reading the question…');

    // ── Step 2: detect question ───────────────────────────────────────────────
    const detection = await detectQuestion(pageText, apiKey, model);
    if (!detection || detection.type === 'none') {
      setLoader(false);
      showMsg('solveMsg', '🔍 No coding or MCQ question detected on this page.', 'info');
      return;
    }

    // Show detected question
    document.getElementById('questionBox').classList.add('show');
    document.getElementById('questionText').textContent = detection.question;
    const badge = document.getElementById('qTypeBadge');
    badge.textContent = detection.type === 'mcq' ? 'MCQ' : 'CODE';
    badge.className = 'badge ' + (detection.type === 'mcq' ? 'badge-mcq' : 'badge-code');
    if (detection.type === 'mcq' && detection.options?.length)
      renderMcqOptions(detection.options, null);

    setLoader(true, 'Generating Java solution…');

    // ── Step 3: solve ─────────────────────────────────────────────────────────
    const answer = await solveQuestion(detection, apiKey, model);
    setLoader(false);
    renderAnswer(detection.type, answer, detection.options || []);

    // ── Step 4: auto-paste ────────────────────────────────────────────────────
    if (autoPaste && detection.type === 'code' && answer.code) {
      await doPaste(answer.code, tab.id);
    }

  } catch (err) {
    setLoader(false);
    showMsg('solveMsg', `❌ Error: ${err.message}`, 'error');
    console.error('[CodeSolver]', err);
  }
}

// ─── Paste into editor (pure executeScript, no messaging) ─────────────────────
async function doPaste(code, tabId) {
  try {
    if (!tabId) {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      tabId = tab.id;
    }
    setLoader(true, 'Pasting into editor…');

    const result = await chrome.scripting.executeScript({
      target: { tabId },
      func: pasteIntoEditor,   // defined below, serialised into the page
      args: [code]
    });

    setLoader(false);
    showPasteStatus(result?.[0]?.result);
  } catch (err) {
    setLoader(false);
    showPasteStatus({ success: false, reason: err.message });
  }
}

// ─── This function is injected into the page by executeScript ─────────────────
// It runs in the page's JS context so it can access window.monaco, CodeMirror, ace
function pasteIntoEditor(code) {

  // 1. Monaco (LeetCode, HackerEarth, Azure) ──────────────────────────────────
  try {
    if (window.monaco && window.monaco.editor) {
      const eds = window.monaco.editor.getEditors();
      if (eds && eds.length > 0) {
        const model = eds[0].getModel();
        if (model) {
          model.setValue(code);
          eds[0].focus();
          return { success: true, editor: 'Monaco' };
        }
      }
    }
  } catch(_) {}

  // Monaco via textarea (fallback for newer LeetCode)
  try {
    const monacoArea = document.querySelector('.monaco-editor textarea');
    if (monacoArea) {
      monacoArea.focus();
      // Select all existing content
      monacoArea.dispatchEvent(new KeyboardEvent('keydown', { key: 'a', code: 'KeyA', ctrlKey: true, bubbles: true }));
      monacoArea.dispatchEvent(new KeyboardEvent('keyup',  { key: 'a', code: 'KeyA', ctrlKey: true, bubbles: true }));
      // Delete then type — use execCommand which monaco listens to
      document.execCommand('selectAll', false, null);
      document.execCommand('insertText', false, code);
      return { success: true, editor: 'Monaco (textarea)' };
    }
  } catch(_) {}

  // 2. CodeMirror 5 (HackerRank, Codeforces) ──────────────────────────────────
  try {
    const cmEls = document.querySelectorAll('.CodeMirror');
    for (const el of cmEls) {
      if (el.CodeMirror) {
        el.CodeMirror.setValue(code);
        el.CodeMirror.focus();
        return { success: true, editor: 'CodeMirror 5' };
      }
    }
  } catch(_) {}

  // 3. CodeMirror 6 ────────────────────────────────────────────────────────────
  try {
    const cm6 = document.querySelector('.cm-content');
    if (cm6) {
      cm6.focus();
      document.execCommand('selectAll', false, null);
      document.execCommand('insertText', false, code);
      return { success: true, editor: 'CodeMirror 6' };
    }
  } catch(_) {}

  // 4. ACE Editor (CodeChef, many judges) ─────────────────────────────────────
  try {
    if (window.ace) {
      const aceEls = document.querySelectorAll('.ace_editor');
      for (const el of aceEls) {
        try {
          window.ace.edit(el).setValue(code, -1);
          return { success: true, editor: 'ACE' };
        } catch(_) {}
      }
    }
  } catch(_) {}

  try {
    const aceEls = document.querySelectorAll('.ace_editor');
    for (const el of aceEls) {
      if (el.env && el.env.editor) {
        el.env.editor.setValue(code, -1);
        return { success: true, editor: 'ACE (env)' };
      }
    }
  } catch(_) {}

  // ACE textarea
  try {
    const aceInput = document.querySelector('.ace_text-input');
    if (aceInput) {
      aceInput.focus();
      document.execCommand('selectAll', false, null);
      document.execCommand('insertText', false, code);
      return { success: true, editor: 'ACE (input)' };
    }
  } catch(_) {}

  // 5. Generic textarea (largest visible) ──────────────────────────────────────
  try {
    const all = Array.from(document.querySelectorAll('textarea')).filter(t => {
      const r = t.getBoundingClientRect();
      return r.width > 50 && r.height > 50 &&
             getComputedStyle(t).display !== 'none' &&
             getComputedStyle(t).visibility !== 'hidden';
    });
    if (all.length > 0) {
      const el = all.reduce((a, b) => {
        const ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect();
        return (ra.width * ra.height) > (rb.width * rb.height) ? a : b;
      });
      el.focus();
      el.select();
      const ok = document.execCommand('insertText', false, code);
      if (!ok || !el.value.includes(code.substring(0, 15))) {
        // Native setter bypasses React/Vue controlled value
        const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
        nativeSetter.call(el, code);
        el.dispatchEvent(new Event('input',  { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
      }
      return { success: true, editor: 'Textarea' };
    }
  } catch(_) {}

  // 6. ContentEditable (some custom editors) ───────────────────────────────────
  try {
    const ceEls = document.querySelectorAll('[contenteditable="true"]');
    for (const el of ceEls) {
      const r = el.getBoundingClientRect();
      if (r.width > 100 && r.height > 50) {
        el.focus();
        document.execCommand('selectAll', false, null);
        document.execCommand('insertText', false, code);
        return { success: true, editor: 'ContentEditable' };
      }
    }
  } catch(_) {}

  return { success: false, editor: null };
}

// ─── AI: detect question ──────────────────────────────────────────────────────
async function detectQuestion(pageText, apiKey, model) {
  const prompt = `Analyze this webpage content and extract the MAIN question. Respond ONLY with valid JSON, no markdown:
{
  "type": "code",
  "question": "full question text here",
  "options": [],
  "constraints": "any constraints",
  "examples": "input/output examples"
}
OR for MCQ:
{
  "type": "mcq",
  "question": "question text",
  "options": ["A. ...", "B. ...", "C. ...", "D. ..."],
  "constraints": "",
  "examples": ""
}
OR if no question: {"type":"none"}

PAGE CONTENT:
${pageText}`;

  const resp = await callOpenRouter(apiKey, model, prompt, 800);
  try { return JSON.parse(resp.trim()); }
  catch {
    const m = resp.match(/\{[\s\S]*?\}/);
    if (m) { try { return JSON.parse(m[0]); } catch(_) {} }
    return { type: 'none' };
  }
}

// ─── AI: solve ────────────────────────────────────────────────────────────────
async function solveQuestion(detection, apiKey, model) {
  if (detection.type === 'code') {
    const prompt = `You are an expert competitive programmer. Solve this problem in JAVA only.

PROBLEM:
${detection.question}

CONSTRAINTS: ${detection.constraints || 'N/A'}
EXAMPLES: ${detection.examples || 'N/A'}

STRICT RULES:
- Output ONLY Java code, absolutely nothing else
- No markdown, no backticks, no explanation
- Write a complete Java solution (class + method)
- Handle ALL edge cases
- Must pass ALL test cases on first attempt
- Use proper Java class structure expected by the platform

Java code only:`;

    const code = await callOpenRouter(apiKey, model, prompt, 1500);
    return { type: 'code', code: cleanCode(code) };
  }

  if (detection.type === 'mcq') {
    const prompt = `Answer this MCQ. Respond ONLY with JSON (no markdown):
{"correct_option":"exact text of correct option","correct_index":0,"explanation":"one sentence why"}

QUESTION: ${detection.question}
OPTIONS:
${(detection.options || []).join('\n')}`;
    const resp = await callOpenRouter(apiKey, model, prompt, 300);
    try { return { type: 'mcq', ...JSON.parse(resp.trim()) }; }
    catch {
      const m = resp.match(/\{[\s\S]*?\}/);
      return m ? { type: 'mcq', ...JSON.parse(m[0]) } : { type: 'mcq', correct_option: resp };
    }
  }
}

// ─── OpenRouter API call ──────────────────────────────────────────────────────
async function callOpenRouter(apiKey, model, prompt, maxTokens = 1000) {
  const resp = await fetch('https://openrouter.ai/api/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
      'HTTP-Referer': 'https://codesolver.ai',
      'X-Title': 'CodeSolver AI'
    },
    body: JSON.stringify({
      model, max_tokens: maxTokens, temperature: 0.1,
      messages: [{ role: 'user', content: prompt }]
    })
  });
  if (!resp.ok) {
    const err = await resp.json().catch(() => ({}));
    throw new Error(err.error?.message || `API error ${resp.status}`);
  }
  const data = await resp.json();
  return data.choices?.[0]?.message?.content || '';
}

// ─── Utility: run a function in the page via executeScript ────────────────────
async function runInPage(tabId, func, args = []) {
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    func,
    args
  });
  return results?.[0]?.result;
}

// ─── UI helpers ───────────────────────────────────────────────────────────────
function renderMcqOptions(options, correctIndex) {
  const c = document.getElementById('mcqOptions');
  c.innerHTML = options.map((opt, i) =>
    `<div class="mcq-option ${correctIndex !== null && i === correctIndex ? 'correct' : ''}">${opt}</div>`
  ).join('');
  c.classList.add('show');
}

function renderAnswer(type, answer, options) {
  const box     = document.getElementById('answerBox');
  const codeEl  = document.getElementById('codeAnswer');
  const textEl  = document.getElementById('textAnswer');
  const label   = document.getElementById('answerLabel');
  const pasteBtn = document.getElementById('pasteBtn');
  box.classList.add('show');

  if (type === 'code') {
    label.textContent = '☕ Java Solution';
    codeEl.textContent = answer.code;
    codeEl.style.display = 'block';
    textEl.style.display = 'none';
    pasteBtn.style.display = 'flex';
  } else {
    label.textContent = '✅ Correct Answer';
    textEl.innerHTML = `<strong>${answer.correct_option || ''}</strong><br/><br/>
      <span style="color:var(--text-muted);font-size:11px;">${answer.explanation || ''}</span>`;
    textEl.style.display = 'block';
    codeEl.style.display = 'none';
    pasteBtn.style.display = 'none';
    if (typeof answer.correct_index === 'number') renderMcqOptions(options, answer.correct_index);
  }
}

function showPasteStatus(result) {
  const el  = document.getElementById('pasteStatus');
  const txt = document.getElementById('pasteStatusText');
  el.style.display = 'flex';
  if (result?.success) {
    txt.innerHTML = `<span style="color:var(--success)">✓ Pasted into <strong>${result.editor}</strong></span>`;
  } else {
    txt.innerHTML = `<span style="color:var(--warning)">⚠ Editor not detected — copy code manually</span>`;
  }
}

function setLoader(visible, text = '') {
  document.getElementById('scanLoader').classList.toggle('show', visible);
  if (text) document.getElementById('loaderText').textContent = text;
  const btn = document.getElementById('scanBtn');
  btn.disabled = visible;
  btn.style.opacity = visible ? '0.6' : '1';
}

function showMsg(id, text, type) {
  const el = document.getElementById(id);
  el.textContent = text;
  el.className = `msg show ${type}`;
  setTimeout(() => el.classList.remove('show'), 5000);
}

function hideAll() {
  ['questionBox', 'mcqOptions', 'answerBox'].forEach(id =>
    document.getElementById(id).classList.remove('show'));
  document.getElementById('pasteStatus').style.display = 'none';
  document.getElementById('solveMsg').classList.remove('show');
  document.getElementById('pasteBtn').style.display = 'none';
}

function cleanCode(code) {
  return code
    .replace(/^```[\w]*\n?/gm, '')
    .replace(/```\s*$/gm, '')
    .trim();
}

function chromeGet(keys) {
  return new Promise(resolve => chrome.storage.local.get(keys, resolve));
}
